<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <!-- Bootstrap core CSS -->
		<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" >
        <title><?php echo e(config('app.name', 'Market')); ?></title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
        <!-- Bootstrap core CSS -->
		<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">

        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/display.css" />

        <?php echo \Livewire\Livewire::styles(); ?>


        <!-- Scripts -->
        <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation-dropdown')->html();
} elseif ($_instance->childHasBeenRendered('TypPZpH')) {
    $componentId = $_instance->getRenderedChildComponentId('TypPZpH');
    $componentTag = $_instance->getRenderedChildComponentTagName('TypPZpH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TypPZpH');
} else {
    $response = \Livewire\Livewire::mount('navigation-dropdown');
    $html = $response->html();
    $_instance->logRenderedChild('TypPZpH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            <!-- Page Heading -->
            <header class="bg-white shadow">
                <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                    <?php echo e($header); ?>

                </div>
            </header>

            <!-- Page Content -->
            <main>
                <?php echo e($slot); ?>

            </main>
        </div>

        <?php echo $__env->yieldPushContent('modals'); ?>
        <footer class="text-muted">
            <div class="container">
                <p class="float-right">
                <a href="#">Back to top</a>
                </p>
            </div>
        </footer>
        <script src="<?php echo e(asset('js/jquery-3.5.1.slim.min.js')); ?>" ></script>
        <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>" ></script>
        <script src="<?php echo e(asset('js/bootstrap.js')); ?>" ></script>
    </body>
</html>
<?php /**PATH /storage/ssd3/033/15527033/resources/views/layouts/app.blade.php ENDPATH**/ ?>
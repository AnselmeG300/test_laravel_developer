 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <head>
		<style>
		  .bd-placeholder-img {
			font-size: 1.125rem;
			text-anchor: middle;
			-webkit-user-select: none;
			-moz-user-select: none;
			-ms-user-select: none;
			user-select: none;
		  }

		  @media (min-width: 768px) {
			.bd-placeholder-img-lg {
			  font-size: 3.5rem;
			}
		  }
		</style>
		<!-- Custom styles for this template -->
		<link href="<?php echo e(asset('css/album.css')); ?>" rel="stylesheet">
	</head>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('My Products')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div>      
        <div class="max-w-7xl mx-auto py-10 sm:px-6 lg:px-8">
            <main role="main">
                <?php if(session('status')): ?>
                    <div class="row">
                        <div class="col-sm-12">
                        <div class="alert alert-success">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <i class="material-icons">close</i>
                            </button>
                            <span><?php echo e(session('status')); ?></span>
                        </div>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if(!(auth()->user()->products->isEmpty())): ?>
                <div class="album py-5 bg-light">
                    <div class="container">
                        <div class="row">
                            <?php $__currentLoopData = auth()->user()->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <div class="card mb-4 shadow-sm" style="border-radius: 10%;">
                                        <img class="img img-responsive" style="height: 250px;  border-radius: 10% 10% 0% 0% ;"  src="<?php echo e(asset($product->picture)); ?>" alt="your image" />
                                        <div class="card-body">
                                        <p class="card-text"><?php echo e($product->description); ?></p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="btn-group">
                                                    <a  class="btn btn-sm btn-outline-primary" href="<?php echo e(route('products.edit', $product)); ?>"  >Edit</a>
                                                </div>
                                                <small class="text-muted"><?php echo e($product->price); ?> FCFA</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                    <div>
                        <h1><strong style="font-weight: bold;"> <?php echo e(auth()->user()->name); ?></strong> you have no registered products.'</h1>
                    </div>
                <?php endif; ?>
            </main>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH /storage/ssd3/033/15527033/resources/views/dashboard.blade.php ENDPATH**/ ?>
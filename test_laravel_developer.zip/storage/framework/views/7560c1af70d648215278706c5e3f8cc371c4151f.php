 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Information Product')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="">
		<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
		<meta name="generator" content="Jekyll v4.1.1">
		<title>Market</title>

		<link rel="canonical" href="https://getbootstrap.com/docs/4.5/examples/album/">

		<!-- Bootstrap core CSS -->
		<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

			<!-- Favicons -->
		<link rel="apple-touch-icon" href="<?php echo e(asset('img/market_icon.png')); ?>" sizes="180x180">
		<link rel="icon" href="<?php echo e(asset('img/market_icon.png')); ?>" sizes="32x32" type="image/png">
		<link rel="icon" href="<?php echo e(asset('img/market_icon.png')); ?>" sizes="16x16" type="image/png">
		<link rel="mask-icon" href="<?php echo e(asset('img/market_icon.png')); ?>" color="#563d7c">
		<link rel="icon" href="<?php echo e(asset('img/market_icon.png')); ?>">
		<meta name="theme-color" content="#563d7c">
		<style>
		  .bd-placeholder-img {
			font-size: 1.125rem;
			text-anchor: middle;
			-webkit-user-select: none;
			-moz-user-select: none;
			-ms-user-select: none;
			user-select: none;
		  }

		  @media (min-width: 768px) {
			.bd-placeholder-img-lg {
			  font-size: 3.5rem;
			}
		  }
		</style>
		<!-- Custom styles for this template -->
		<link href="<?php echo e(asset('css/album.css')); ?>" rel="stylesheet">
	</head>
	<body>

<main role="main">


  <div class="album py-5 bg-light">
	<div class="container">

	  <div class="row">
		<div class="col-md-4">
		  <div class="card mb-4 shadow-sm">
			<svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">Thumbnail</text></svg>
			<div class="card-body">
			  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
			  <div class="d-flex justify-content-between align-items-center">
				<div class="btn-group">
				  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
				  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
				</div>
				<small class="text-muted">9 mins</small>
			  </div>
			</div>
		  </div>
		</div>
		<div class="col-md-4">
		  <div class="card mb-4 shadow-sm">
			<svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">Thumbnail</text></svg>
			<div class="card-body">
			  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
			  <div class="d-flex justify-content-between align-items-center">
				<div class="btn-group">
				  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
				  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
				</div>
				<small class="text-muted">9 mins</small>
			  </div>
			</div>
		  </div>
		</div>
		<div class="col-md-4">
		  <div class="card mb-4 shadow-sm">
			<svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">Thumbnail</text></svg>
			<div class="card-body">
			  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
			  <div class="d-flex justify-content-between align-items-center">
				<div class="btn-group">
				  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
				  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
				</div>
				<small class="text-muted">9 mins</small>
			  </div>
			</div>
		  </div>
		</div>

		<div class="col-md-4">
		  <div class="card mb-4 shadow-sm">
			<svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">Thumbnail</text></svg>
			<div class="card-body">
			  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
			  <div class="d-flex justify-content-between align-items-center">
				<div class="btn-group">
				  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
				  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
				</div>
				<small class="text-muted">9 mins</small>
			  </div>
			</div>
		  </div>
		</div>
		<div class="col-md-4">
		  <div class="card mb-4 shadow-sm">
			<svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">Thumbnail</text></svg>
			<div class="card-body">
			  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
			  <div class="d-flex justify-content-between align-items-center">
				<div class="btn-group">
				  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
				  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
				</div>
				<small class="text-muted">9 mins</small>
			  </div>
			</div>
		  </div>
		</div>
		<div class="col-md-4">
		  <div class="card mb-4 shadow-sm">
			<svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">Thumbnail</text></svg>
			<div class="card-body">
			  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
			  <div class="d-flex justify-content-between align-items-center">
				<div class="btn-group">
				  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
				  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
				</div>
				<small class="text-muted">9 mins</small>
			  </div>
			</div>
		  </div>
		</div>

		<div class="col-md-4">
		  <div class="card mb-4 shadow-sm">
			<svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">Thumbnail</text></svg>
			<div class="card-body">
			  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
			  <div class="d-flex justify-content-between align-items-center">
				<div class="btn-group">
				  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
				  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
				</div>
				<small class="text-muted">9 mins</small>
			  </div>
			</div>
		  </div>
		</div>
		<div class="col-md-4">
		  <div class="card mb-4 shadow-sm">
			<svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">Thumbnail</text></svg>
			<div class="card-body">
			  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
			  <div class="d-flex justify-content-between align-items-center">
				<div class="btn-group">
				  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
				  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
				</div>
				<small class="text-muted">9 mins</small>
			  </div>
			</div>
		  </div>
		</div>
		<div class="col-md-4">
		  <div class="card mb-4 shadow-sm">
			<svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">Thumbnail</text></svg>
			<div class="card-body">
			  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
			  <div class="d-flex justify-content-between align-items-center">
				<div class="btn-group">
				  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
				  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
				</div>
				<small class="text-muted">9 mins</small>
			  </div>
			</div>
		  </div>
		</div>
	  </div>
	</div>
  </div>

</main>

<footer class="text-muted">
  <div class="container">
	<p class="float-right">
	  <a href="#">Back to top</a>
	</p>
	<p>Album example is &copy; Bootstrap, but please download and customize it for yourself!</p>
	<p>New to Bootstrap? <a href="https://getbootstrap.com/">Visit the homepage</a> or read our <a href="/docs/4.5/getting-started/introduction/">getting started guide</a>.</p>
  </div>
</footer>
<script src="<?php echo e(asset('js/jquery-3.5.1.slim.min.js')); ?>" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	  <script>window.jQuery || document.write('<script src="https://getbootstrap.com/docs/4.5/assets/js/vendor/jquery.slim.min.js"><\/script>')</script><script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script></body>
 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

<?php /**PATH C:\Users\Anselme\Documents\BRIDGE AFRICA VENTURES\test_laravel_developer\resources\views/product/index.blade.php ENDPATH**/ ?>